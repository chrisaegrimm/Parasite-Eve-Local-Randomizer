--Base Options 
Seed = 0                  -- 0 for random seed
PEShuffle = true
--PEMode = 0 					  -- 0 = levels, 1 = item pool
WeaponShuffle = true
--WeaponMode = 3				  -- 0 = shuffle, 1 = random stats, 2 = random mods, 3 = full random
--Chrystler = false
Override = 0                      -- 0 = none, 1 = club%, 2 = hidden potential

--Weapon Shuffle Options  Max: 255
 OffMax=60                      
 OffMin=1
 RngMax=60
 RngMin=1
 BltMax=60
 BltMin=1
 OffPlusMax=4
 OffPlusMin=1
 RngPlusMax=4
 RngPlusMin=1
 BltPlusMax=4
 BltPlusMin=1
 WeaponModMax=6
 WeaponModMin=1

--Armor Shuffle Options
 DefMax=40
 DefMin=1
 PEnMax=40
 PEnMin=1
 CrtMax=40
 CrtMin=1
 DefPlusMax=4
 DefPlusMin=1
 PEnPlusMax=4
 PEnPlusMin=1
 CrtPlusMax=4
 CrtPlusMin=1
 ArmorModMax=6
 ArmorModMin=1